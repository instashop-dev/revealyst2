import './assets/service-worker.ts-Bbrlv9En.js';
